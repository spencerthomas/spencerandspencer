import styled from 'styled-components';

const ProcessItem = styled.div`
  position: relative;
`;

export default ProcessItem;
